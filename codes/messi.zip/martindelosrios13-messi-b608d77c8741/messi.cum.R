group.id = 22
dir = 'messi_par'
est = TRUE
mul = TRUE
par = TRUE
