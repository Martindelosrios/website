#---------------------------INPUT FILES-----------------------------------

#The name of the file where the galaxies information is stored, the default is 'prueba.dat'.
#It must have the same structure as 'prueba.dat'
input.file.name = 'prueba.dat'

#---------------------------TRAINSET FILES-----------------------------------

#The name of the trainset file for the clusters. The default is 'trainset_cum.dat'
#If you want to change the trainset for the clusters you must have
#  the same structure as 'trainset_cum.dat'
name_trainset_cum = 'trainset_cum.dat'
#The name of the trainset file for galaxies. The default is 'trainset_cum.dat'
#If you want to change the trainset for the galaxies you must have
#  the same structure as 'trainset_galaxies.dat'
name_trainset_gal = 'trainset_gal.dat'


#---------------------------OUTPUT FILES-----------------------------------

#The name of the folder where all the information will be stored 
#The default is 'prueba_messi'
folder = 'prueba_messi'
#The name of the output file where the galaxies properties will be stored. 
#The default is 'estadisticos_galaxias.dat'
name.gal = 'estadisticos_galaxias.dat'
#The name of the output file where the clusters properties will be stored. 
#The default is 'estadisticos_grupos.dat'
name.groups = 'estadisticos_grupos.dat'
#The name of the output file where the merging-classification properties 
#  will be stored. 
#The default is 'ranking.dat'
rank.name = 'ranking.dat'
#The name of the output file where the relaxed-classification properties 
#  will be stored. 
#The default is 'ranking_relaxed.dat'
relaxed.name = 'ranking_relaxed.dat'
 
#-------------------------CONFIGURATION PARAMETERS--------------------------

nrank = 100 #Number of random forest instances you want to do
cum   = TRUE #change to FALSE if you have alredy estimate the clusters properties.
gal   = TRUE #change to FALSE if you have alredy estimate the galaxy properties.
rank  = TRUE #change to FALSE if you do not want to performed a merging classification
relaxed = TRUE #change to FALSE if you do not want to performed a relaxed classification
est = TRUE #change to FALSE if you do not want to performed an stability test for each cluster
ncluster = 8 #Number of cluster to be used in the computation, if you set to 0, then the computation will not be parallel
ngal.lim = 30 #Minimum number of galaxies that must have the cluster in order to being analyzed. The default and the recomendated is 30.

#---------------------- LIME EXPLANATION ------------------------
# Only if you want to explained some cluster classification after 
# the running of MeSsI.
id = 1 # Id of the cluster which classification will be explained by LIME

dat <- read.table(input.file.name,header=T)

